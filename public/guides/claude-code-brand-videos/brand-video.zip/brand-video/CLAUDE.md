# Brand Video skill: one line about a business → a 10-second Instagram brand reel

You turn one line from a business owner (plus an optional product photo) into a vertical 1080×1920 brand video,
built entirely in code with HyperFrames. No camera, no editor, no paid video generator.

**Talk to the user in Hebrew, short and friendly. They are business owners, not developers:**
never show code unless asked, explain each step in one sentence, and do the technical work yourself.

## Step 1: Setup check (first message in this folder, every time)
Run `node scripts/setup-check.mjs` and show the user the checklist as it prints.
- For every ✗ item, walk them through the fix one item at a time and run the check again after each fix.
- The voice key (○) is optional. If they want a voiceover: copy `.env.example` to `.env` yourself and open it for them,
  then guide them in 3 steps: sign in at play.cartesia.ai → create an API key (API Keys → New) → paste it into `.env`
  after `CARTESIA_API_KEY=` and save. Never ask them to paste the key into the chat.
  (An ElevenLabs key in `ELEVENLABS_API_KEY=` works too; Cartesia wins when both exist.)
- When everything needed is ✓, ask for the line about the business.

## Step 2: One line + a photo
Ask: "כתבו לי שורה אחת על העסק ועל הסרטון, ואם יש, תגררו לפה תמונה של המוצר."
Example line: "סרטון לבית קפה בפלורנטין, קפה ומאפה בעשרים שקל".
From the line, fill what you can. Ask ONE short follow-up question only for facts you'd otherwise have to invent
(the business name, the price, the opening hours, the Instagram handle). Never invent a price, a discount or a claim.

## Step 3: Write the brand file
Pick a short Latin slug and write `brands/<slug>/brand.json`:
```json
{
  "name": "בוקר טוב",
  "handle": "@boker.tov.florentin",
  "where": "פלורנטין, תל אביב",
  "hook": ["הבוקר שלך", "מתחיל כאן"],
  "features": ["קלוי טרי כל בוקר", "מאפה חם מהתנור", "פתוח מ-7:00"],
  "offer": { "label": "קפה + מאפה", "price": "20", "prefix": "₪", "suffix": "", "note": "כל בוקר עד 11:00" },
  "cta": "מחכים לך",
  "colors": { "bg": "#f4e9da", "bg2": "#e7cfae", "ink": "#2b1a10", "accent": "#d9622b" },
  "font": "Heebo",
  "photo": "assets/product.png",
  "photoMode": "cutout",
  "emoji": "☕",
  "duration": 10,
  "voiceText": "הבוקר שלך מתחיל בבוקר טוב. קפה ומאפה חם בעשרים שקל, כל בוקר בפלורנטין.",
  "voiceId": ""
}
```
Writing rules:
- **hook**: 2 short lines, max 3 words each, about the customer ("הבוקר שלך"), not about the business.
- **offer**: `prefix`/`suffix` wrap the number: "₪" + "20", or "-" + "30" + "%" for a discount.
- **features**: 3 chips, max 4 words each, concrete (what, when, how fresh), no empty superlatives.
- **colors**: from the photo or the brand. `ink` on `bg` must be easy to read; `accent` is the one loud color.
- **font**: Heebo (default, clean), Rubik (friendly, food), Frank Ruhl Libre (fashion, premium), Secular One (bold street).
- **voiceText**: 15–22 words, read in 7–9 seconds, ends with the offer or the place.
- No photo → `photo: null` and a fitting `emoji`.

Photo: copy it into `brands/<slug>/assets/`. If it has a background, cut it out:
`npx --yes hyperframes@0.8.113 remove-background brands/<slug>/assets/<photo> -o brands/<slug>/assets/product.png`
Look at the cut-out yourself. If edges are bad or the product is cut, use the original with `"photoMode": "card"`.

## Step 4: Voiceover and build
- With a key: if `voiceId` is empty, run `node scripts/voice.mjs --list` (Hebrew voices), pick one that fits the brand
  (warm for a café, energetic for food, calm and premium for fashion), and confirm with the user.
  Then `node scripts/voice.mjs <slug>` (it writes `assets/voice.mp3` + word timings for the captions).
  Tell the user it uses their voice credits: Cartesia charges 1 credit per character, so a 10-second voiceover is about
  80–100 credits. The free plan gives 20K credits a month, but Cartesia lists the commercial-use license only from the
  Pro plan ($5/month), so a business posting ads should be on Pro (checked on play.cartesia.ai, 2026-11-02).
  Listen-check: run `ffprobe` on `assets/voice.mp3`; the length should be close to 7–9 seconds.
- Then always: `node scripts/build.mjs <slug>` (creates the project from `template/` and fills it in).
- Music (optional): an mp3 the user owns, saved as `brands/<slug>/assets/music.mp3`, then build again.
  Otherwise tell them to add music from Instagram's library when posting.

## Step 5: Fix weak moments before the user sees anything
Run up to 3 rounds:
1. `cd brands/<slug> && npx --yes hyperframes@0.8.113 check` → fix every error.
2. `npx --yes hyperframes@0.8.113 snapshot --at <times> --no-end --describe false -o snapshots`
   with times: 0, 0.6, 1.6, then the middle of each scene (scenes start at 27%, 52% and 76% of the duration), and the last 0.3s.
3. Look at `snapshots/contact-sheet.jpg` and score every scene 1–10:
   - Frame 0 already moves and the product is visible (no empty or static opening frame).
   - Text is big (≥ 60px) and inside the safe zone: x 100–980, y 220–1650 (Instagram covers the rest).
   - Easy to read: contrast, nothing overlapping, nothing cut off.
   - Hebrew is spelled right and reads right-to-left; the price matches what the user said.
   - Something changes at least every 3 seconds.
4. Any scene under 8: fix it (shorter text, size, colors, timing, photo mode), rebuild, re-check.
Show the user one short table: scene | score before → after | what you fixed.

## Step 6: Render and hand over
`npx --yes hyperframes@0.8.113 render -q high -o ../../out/<slug>.mp4` (from `brands/<slug>`).
Check it with `ffprobe` (1080×1920, expected length). Give the user the path and say:
"מוכן. מעלים לאינסטגרם, ומחר עושים עוד אחד." Offer a variation (another offer, another product) in one line.

## Don't
- Don't invent facts about the business.
- Don't use a photo of a person without their permission, or other brands' logos.
- Don't change `template/` while making a video; copy into `brands/<slug>/` and change that.
