#!/usr/bin/env node
// Usage: node scripts/build.mjs <slug>
// Creates brands/<slug>/ from the template on first run, then injects brand.json
// (plus voice + captions when they exist) into its index.html.
import { existsSync, mkdirSync, readFileSync, writeFileSync, copyFileSync, readdirSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const slug = process.argv[2];
if (!slug) {
  console.error("usage: node scripts/build.mjs <slug>");
  process.exit(1);
}
const dir = join(ROOT, "brands", slug);
const brandFile = join(dir, "brand.json");
if (!existsSync(brandFile)) {
  console.error(`missing ${brandFile}`);
  process.exit(1);
}

if (!existsSync(join(dir, "index.html"))) {
  mkdirSync(join(dir, "assets"), { recursive: true });
  for (const f of ["index.html", "package.json", "hyperframes.json", "meta.json"]) {
    copyFileSync(join(ROOT, "template", f), join(dir, f));
  }
  for (const f of readdirSync(join(ROOT, "template", "assets"))) {
    if (f !== ".keep") copyFileSync(join(ROOT, "template", "assets", f), join(dir, "assets", f));
  }
}

const brand = JSON.parse(readFileSync(brandFile, "utf8"));

function probeSeconds(file) {
  try {
    const out = execFileSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", file]);
    return parseFloat(out.toString());
  } catch {
    return null;
  }
}

// Short caption chunks read faster than full sentences: 1-3 words, break on punctuation.
function chunk(words) {
  const out = [];
  let cur = [];
  const flush = () => {
    if (!cur.length) return;
    out.push([cur[0][0], cur[cur.length - 1][1], cur.map((w) => w[2]).join(" ")]);
    cur = [];
  };
  for (const w of words) {
    cur.push(w);
    const text = cur.map((x) => x[2]).join(" ");
    if (/[.,!?:;]$/.test(w[2]) || cur.length === 3 || text.length > 14) flush();
  }
  flush();
  for (let i = 0; i < out.length - 1; i++) out[i][1] = Math.max(out[i][1], out[i + 1][0]);
  return out.map(([s, e, t]) => [+s.toFixed(2), +e.toFixed(2), t.replace(/[.,;:]$/, "")]);
}

const voicePath = join(dir, "assets", "voice.mp3");
const wordsPath = join(dir, "assets", "words.json");
const musicPath = join(dir, "assets", "music.mp3");
const hasVoice = existsSync(voicePath);
const hasMusic = existsSync(musicPath);

let duration = brand.duration || 10;
let captions = [];
if (hasVoice) {
  const vd = probeSeconds(voicePath);
  if (vd) duration = Math.max(duration, +(vd + 0.9).toFixed(2));
  if (existsSync(wordsPath)) captions = chunk(JSON.parse(readFileSync(wordsPath, "utf8")));
}

const data = {
  name: brand.name,
  handle: brand.handle || "",
  where: brand.where || "",
  hook: brand.hook,
  features: brand.features || [],
  offer: brand.offer,
  cta: brand.cta || "מחכים לך",
  colors: brand.colors,
  font: brand.font || "Heebo",
  photo: brand.photo || null,
  photoMode: brand.photoMode || "cutout",
  emoji: brand.emoji || "⭐",
  duration,
  captions,
};

let html = readFileSync(join(dir, "index.html"), "utf8");
html = html.replace(
  /\/\*BRAND_START\*\/[\s\S]*?\/\*BRAND_END\*\//,
  `/*BRAND_START*/\n      const BRAND = ${JSON.stringify(data, null, 2).replace(/\n/g, "\n      ")};\n      /*BRAND_END*/`,
);
html = html.replace(/(id="root"[^>]*data-duration=")[\d.]+(")/, `$1${duration}$2`);

const audio = [];
if (hasVoice) audio.push(`<audio id="vo" data-start="0" data-duration="${duration}" data-volume="1" src="assets/voice.mp3"></audio>`);
if (hasMusic) {
  const vol = hasVoice ? 0.18 : 0.8;
  audio.push(`<audio id="music" data-start="0" data-duration="${duration}" data-volume="${vol}" data-fade-out="1" src="assets/music.mp3"></audio>`);
}
html = html.replace(/<!--AUDIO_START-->[\s\S]*?<!--AUDIO_END-->/, `<!--AUDIO_START-->${audio.join("")}<!--AUDIO_END-->`);

writeFileSync(join(dir, "index.html"), html);
console.log(JSON.stringify({ slug, duration, voice: hasVoice, music: hasMusic, captions: captions.length, dir }, null, 2));
