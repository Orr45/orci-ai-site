#!/usr/bin/env node
// Usage: node scripts/setup-check.mjs
// Checks everything the skill needs and prints one line per item, with the fix for anything missing.
import { execSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const win = process.platform === "win32";
const mac = process.platform === "darwin";

function run(cmd) {
  try {
    return execSync(cmd, { stdio: ["ignore", "pipe", "pipe"], timeout: 180000 }).toString().trim();
  } catch {
    return null;
  }
}

function readEnv() {
  const f = join(ROOT, ".env");
  if (!existsSync(f)) return {};
  return Object.fromEntries(
    readFileSync(f, "utf8")
      .split(/\r?\n/)
      .filter((l) => l.includes("=") && !l.trim().startsWith("#"))
      .map((l) => [l.slice(0, l.indexOf("=")).trim(), l.slice(l.indexOf("=") + 1).trim().replace(/^["']|["']$/g, "")]),
  );
}

const items = [];
const major = parseInt(process.versions.node.split(".")[0], 10);
items.push({
  name: "Node.js",
  ok: major >= 22,
  detail: `v${process.versions.node}`,
  fix: "צריך Node.js 22 ומעלה: https://nodejs.org (מורידים LTS ומתקינים)",
});

const ff = run("ffmpeg -version");
items.push({
  name: "ffmpeg",
  ok: !!ff,
  detail: ff ? ff.split("\n")[0].split(" ").slice(0, 3).join(" ") : "לא נמצא",
  fix: mac ? "brew install ffmpeg" : win ? "winget install Gyan.FFmpeg (ואז לפתוח טרמינל חדש)" : "sudo apt install ffmpeg",
});

const chrome = ff ? run("npx --yes hyperframes@0.8.113 browser ensure") : null;
items.push({
  name: "HyperFrames + Chrome לרינדור",
  ok: !!chrome,
  detail: chrome ? "מוכן" : "לא מוכן",
  fix: "npx --yes hyperframes@0.8.113 browser ensure (מוריד פעם אחת את הדפדפן לרינדור)",
});

const env = readEnv();
const cartesia = env.CARTESIA_API_KEY || process.env.CARTESIA_API_KEY;
const eleven = env.ELEVENLABS_API_KEY || process.env.ELEVENLABS_API_KEY;
const key = cartesia || eleven;
items.push({
  name: "מפתח קול (Cartesia)",
  ok: !!key,
  optional: true,
  detail: cartesia ? "Cartesia נמצא ב-.env" : eleven ? "ElevenLabs נמצא ב-.env" : "חסר",
  fix: "play.cartesia.ai → Sign in → API Keys → New key → להעתיק ל-.env בשורה CARTESIA_API_KEY=",
});

for (const it of items) {
  const mark = it.ok ? "✓" : it.optional ? "○" : "✗";
  console.log(`${mark} ${it.name}: ${it.detail}${it.ok ? "" : `\n    איך מתקנים: ${it.fix}`}`);
}
const blocking = items.filter((i) => !i.ok && !i.optional);
console.log(
  blocking.length
    ? `\nחסרים ${blocking.length} דברים לפני שאפשר להתחיל.`
    : key
      ? "\nהכול מוכן."
      : "\nהכול מוכן. בלי מפתח קול הסרטון יצא בלי קריינות, ואפשר להוסיף מוזיקה באינסטגרם.",
);
process.exit(blocking.length ? 1 : 0);
