#!/usr/bin/env node
// Usage:
//   node scripts/voice.mjs --list            list Hebrew voices (free)
//   node scripts/voice.mjs <slug>            voice brand.json "voiceText" → brands/<slug>/assets/voice.mp3 + words.json
//   node scripts/voice.mjs <slug> --retime   redo only the caption timings from the existing voice.mp3 (free)
// Provider: Cartesia when CARTESIA_API_KEY is in .env (default), otherwise ElevenLabs (ELEVENLABS_API_KEY).
// brand.json may set "voiceId" (and "voiceModel").
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { execFileSync, spawnSync } from "node:child_process";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");

function readEnv() {
  const f = join(ROOT, ".env");
  if (!existsSync(f)) return {};
  return Object.fromEntries(
    readFileSync(f, "utf8")
      .split(/\r?\n/)
      .filter((l) => l.includes("=") && !l.trim().startsWith("#"))
      .map((l) => [l.slice(0, l.indexOf("=")).trim(), l.slice(l.indexOf("=") + 1).trim().replace(/^["']|["']$/g, "")]),
  );
}

const env = readEnv();
const cartesiaKey = env.CARTESIA_API_KEY || process.env.CARTESIA_API_KEY;
const elevenKey = env.ELEVENLABS_API_KEY || process.env.ELEVENLABS_API_KEY;
if (!cartesiaKey && !elevenKey) {
  console.error("MISSING_KEY: add CARTESIA_API_KEY=... (or ELEVENLABS_API_KEY=...) to .env");
  process.exit(2);
}
const provider = cartesiaKey ? "cartesia" : "elevenlabs";

const CARTESIA = "https://api.cartesia.ai";
const cartesiaHeaders = { "X-API-Key": cartesiaKey, "Cartesia-Version": "2025-04-16", "Content-Type": "application/json" };
const ELEVEN = "https://api.elevenlabs.io/v1";
const elevenHeaders = { "xi-api-key": elevenKey, "Content-Type": "application/json" };

async function fail(res) {
  console.error(`HTTP ${res.status}: ${(await res.text()).slice(0, 500)}`);
  process.exit(1);
}

if (process.argv[2] === "--list") {
  if (provider === "cartesia") {
    const res = await fetch(`${CARTESIA}/voices?language=he&limit=50`, { headers: cartesiaHeaders });
    if (!res.ok) await fail(res);
    const { data } = await res.json();
    for (const v of data) console.log(`${v.id}  ${v.name}  — ${(v.description || "").slice(0, 70)}`);
  } else {
    const res = await fetch(`${ELEVEN}/voices`, { headers: elevenHeaders });
    if (!res.ok) await fail(res);
    const { voices } = await res.json();
    for (const v of voices) console.log(`${v.voice_id}  ${v.name}  (${v.category})`);
  }
  process.exit(0);
}

const slug = process.argv[2];
if (!slug) {
  console.error("usage: node scripts/voice.mjs <slug> | --list");
  process.exit(1);
}
const dir = join(ROOT, "brands", slug);
const brand = JSON.parse(readFileSync(join(dir, "brand.json"), "utf8"));
if (!brand.voiceText) {
  console.error('brand.json has no "voiceText"');
  process.exit(1);
}
if (!brand.voiceId) {
  console.error('brand.json has no "voiceId" (run: node scripts/voice.mjs --list)');
  process.exit(1);
}
mkdirSync(join(dir, "assets"), { recursive: true });
const mp3 = join(dir, "assets", "voice.mp3");

function wavFromPcm(pcm, rate) {
  const h = Buffer.alloc(44);
  h.write("RIFF", 0);
  h.writeUInt32LE(36 + pcm.length, 4);
  h.write("WAVEfmt ", 8);
  h.writeUInt32LE(16, 16);
  h.writeUInt16LE(1, 20);
  h.writeUInt16LE(1, 22);
  h.writeUInt32LE(rate, 24);
  h.writeUInt32LE(rate * 2, 28);
  h.writeUInt16LE(2, 32);
  h.writeUInt16LE(16, 34);
  h.write("data", 36);
  h.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([h, pcm]);
}

const retime = process.argv.includes("--retime");
let words = [];
if (retime) {
  if (!existsSync(mp3)) {
    console.error(`no ${mp3} to retime`);
    process.exit(1);
  }
} else if (provider === "cartesia") {
  const model = brand.voiceModel || "sonic-3.6";
  const rate = 44100;
  const res = await fetch(`${CARTESIA}/tts/sse`, {
    method: "POST",
    headers: cartesiaHeaders,
    body: JSON.stringify({
      model_id: model,
      transcript: brand.voiceText,
      voice: { mode: "id", id: brand.voiceId },
      language: "he",
      output_format: { container: "raw", encoding: "pcm_s16le", sample_rate: rate },
      add_timestamps: true,
    }),
  });
  if (!res.ok) await fail(res);
  const text = await res.text();
  const chunks = [];
  for (const line of text.split(/\r?\n/)) {
    if (!line.startsWith("data:")) continue;
    let ev;
    try {
      ev = JSON.parse(line.slice(5).trim());
    } catch {
      continue;
    }
    if (ev.type === "chunk" && ev.data) chunks.push(Buffer.from(ev.data, "base64"));
    if (ev.type === "timestamps" && ev.word_timestamps) {
      const wt = ev.word_timestamps;
      wt.words.forEach((w, i) => words.push([wt.start[i], wt.end[i], w]));
    }
    if (ev.type === "error") {
      console.error(JSON.stringify(ev));
      process.exit(1);
    }
  }
  const wav = join(dir, "assets", "voice.wav");
  writeFileSync(wav, wavFromPcm(Buffer.concat(chunks), rate));
  execFileSync("ffmpeg", ["-y", "-loglevel", "error", "-i", wav, "-b:a", "192k", mp3]);
} else {
  const model = brand.voiceModel || "eleven_v3";
  const res = await fetch(`${ELEVEN}/text-to-speech/${brand.voiceId}/with-timestamps?output_format=mp3_44100_128`, {
    method: "POST",
    headers: elevenHeaders,
    body: JSON.stringify({ text: brand.voiceText, model_id: model }),
  });
  if (!res.ok) await fail(res);
  const out = await res.json();
  writeFileSync(mp3, Buffer.from(out.audio_base64, "base64"));
  // character timings → word timings, so captions land on the spoken word
  const al = out.alignment || out.normalized_alignment;
  let cur = "";
  let start = null;
  let end = 0;
  al.characters.forEach((ch, i) => {
    if (/\s/.test(ch)) {
      if (cur) words.push([start, end, cur]);
      cur = "";
      start = null;
      return;
    }
    if (start === null) start = al.character_start_times_seconds[i];
    end = al.character_end_times_seconds[i];
    cur += ch;
  });
  if (cur) words.push([start, end, cur]);
}

// Cartesia's Hebrew word timestamps come back evenly spaced (checked against Whisper: up to 0.4s off),
// so for Cartesia, and whenever a provider gives none, place the words on the speech itself:
// find the pauses with ffmpeg, then spread the words over the voiced parts by length.
if (retime || provider === "cartesia" || !words.length) {
  const secs = parseFloat(
    execFileSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", mp3]).toString(),
  );
  const text = spawnSync("ffmpeg", ["-hide_banner", "-i", mp3, "-af", "silencedetect=noise=-35dB:d=0.12", "-f", "null", "-"], {
    encoding: "utf8",
  }).stderr;
  const starts = [...text.matchAll(/silence_start: ([\d.]+)/g)].map((m) => +m[1]);
  const ends = [...text.matchAll(/silence_end: ([\d.]+)/g)].map((m) => +m[1]);
  const voiced = [];
  let t = 0;
  starts.forEach((s, i) => {
    if (s - t > 0.05) voiced.push([t, s]);
    t = ends[i] ?? secs;
  });
  if (secs - t > 0.05) voiced.push([t, secs]);
  const speech = voiced.reduce((a, [s, e]) => a + (e - s), 0);
  const at = (x) => {
    for (const [s, e] of voiced) {
      if (x <= e - s) return s + x;
      x -= e - s;
    }
    return secs;
  };
  const list = brand.voiceText.split(/\s+/).filter(Boolean);
  const total = list.reduce((s, w) => s + w.replace(/[^\p{L}\p{N}]/gu, "").length + 1, 0);
  let acc = 0;
  words = list.map((w) => {
    const d = ((w.replace(/[^\p{L}\p{N}]/gu, "").length + 1) / total) * speech;
    const item = [+at(acc).toFixed(2), +at(acc + d).toFixed(2), w];
    acc += d;
    return item;
  });
}
writeFileSync(join(dir, "assets", "words.json"), JSON.stringify(words));
console.log(JSON.stringify({ slug, provider, chars: brand.voiceText.length, words: words.length }));
