"""הדוגמה: בונה את המורה על חומר דמו (מבוא לכלכלה, הרצאה 2: עקומת התמורה) ופותח את הממשק המונפש.

  python scripts/demo.py [--out runs/demo]
"""
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):  # Windows consoles default to cp1252/cp1255 and crash on Hebrew / ✓
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent

ap = argparse.ArgumentParser()
ap.add_argument("--out", default=str(HERE / "runs/demo"))
ap.add_argument("--open", default="studio", choices=["studio", "site", "none"])
a = ap.parse_args()
run = Path(a.out).expanduser()
run.mkdir(parents=True, exist_ok=True)
demo = HERE / "demo"
subprocess.run([sys.executable, str(HERE / "scripts/extract.py"), "--slides", str(demo / "lecture-2.pdf"),
                "--homework", str(demo / "homework-2.pdf"), "--out", str(run)], check=True)
shutil.copy(demo / "course.json", run / "course.json")
shutil.copy(demo / "lab.html", run / "lab.html")
subprocess.run([sys.executable, str(HERE / "scripts/build.py"), "--run", str(run), "--open", a.open], check=True)
