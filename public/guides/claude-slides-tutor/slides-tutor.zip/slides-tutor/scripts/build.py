"""שלב 3: בונה את שני הדפים מתוך RUN/course.json + RUN/extract.json.

  python scripts/build.py --run RUN [--open studio|site|none]

כותב:
  RUN/site/index.html     אתר התרגול: רמזים, שקפים, שלבים, פתרון, מד התקדמות, המורה מסביר, מעבדה
  RUN/studio/index.html   הממשק המונפש לצילום: השקפים נפרשים, מושגים נשאבים, כל שאלה מתחברת לשקף שלה, והאתר נבנה

שני הדפים עובדים בלי שרת (פותחים את הקובץ בדפדפן). F = מסך מלא, R = מההתחלה.
"""
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):  # Windows consoles default to cp1252/cp1255 and crash on Hebrew / ✓
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse
import json
import shutil
import sys
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
TPL = HERE / "templates"


def fail(msg):
    sys.exit(f"✗ {msg}")


def check(course, extract):
    nums = {s["n"] for s in extract["slides"]}
    errs = []
    for k in ("course", "title", "topics", "exercises"):
        if k not in course:
            errs.append(f"חסר השדה {k}")
    for t in course.get("topics", []):
        for c in t.get("concepts", []):
            if c.get("slide") not in nums:
                errs.append(f"מושג '{c.get('text')}' מפנה לשקף {c.get('slide')} שלא קיים")
        for s in t.get("slides", []):
            if s not in nums:
                errs.append(f"נושא '{t['name']}' מפנה לשקף {s} שלא קיים")
    topic_ids = {t["id"] for t in course.get("topics", [])}
    page_nums = {p["n"] for p in extract.get("pages", [])}
    for t in course.get("topics", []):
        if not any(e.get("topic") == t["id"] for e in course.get("exercises", [])):
            print(f"! נושא '{t['name']}' בלי תרגילים: הוא יופיע באנימציה, אבל לא יקבל לשונית באתר")
    for e in course.get("exercises", []):
        if e.get("topic") not in topic_ids:
            errs.append(f"תרגיל {e.get('id')}: נושא {e.get('topic')} לא מוגדר")
        if not e.get("graded") and not e.get("parts"):
            errs.append(f"תרגיל {e.get('id')}: אין parts")
        for p in ([] if e.get("graded") else e.get("parts", [])):
            if p.get("type") == "choice" and not (0 <= p.get("answer", -1) < len(p.get("options", []))):
                errs.append(f"תרגיל {e.get('id')}: answer מחוץ לטווח האפשרויות")
            if p.get("type") == "number" and not isinstance(p.get("answer"), (int, float)):
                errs.append(f"תרגיל {e.get('id')}: answer מספרי חסר")
        hints = e.get("hints", [])
        if len(hints) != 2:
            errs.append(f"תרגיל {e.get('id')}: צריך בדיוק 2 רמזים (יש {len(hints)})")
        elif hints[0].get("slide") is None:
            errs.append(f"תרגיל {e.get('id')}: ברמז 1 חסר slide")
        for h in hints:
            if h.get("slide") is not None and h["slide"] not in nums:
                errs.append(f"תרגיל {e.get('id')}: רמז מפנה לשקף {h['slide']} שלא קיים")
        if not e.get("steps"):
            errs.append(f"תרגיל {e.get('id')}: אין steps")
        if e.get("page") is not None and page_nums and e["page"] not in page_nums:
            errs.append(f"תרגיל {e.get('id')}: page {e['page']} לא קיים בדף התרגיל")
    for l in course.get("lessons", []):
        if l.get("slide") is not None and l["slide"] not in nums:
            errs.append(f"שיעור '{l.get('title')}' מפנה לשקף {l['slide']} שלא קיים")
        if not l.get("lines"):
            errs.append(f"שיעור '{l.get('title')}' בלי lines")
    if errs:
        fail("בעיות ב-course.json:\n  " + "\n  ".join(errs))


def write_page(run, name, tpl, data, extract, with_pages):
    out = run / name
    out.mkdir(parents=True, exist_ok=True)
    shutil.copy(TPL / tpl, out / "index.html")
    (out / "data.js").write_text("window.COURSE = " + json.dumps(data, ensure_ascii=False) + ";\n", encoding="utf-8")
    dst = out / "slides"
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(run / "slides", dst)
    if with_pages:
        dst = out / "pages"
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(run / "pages", dst)
    return out / "index.html"



def open_page(path):
    """Open a local page in the default browser; the OS opener is more reliable than webbrowser on macOS/Windows."""
    import os
    import subprocess
    try:
        if sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=True, timeout=20)
        elif sys.platform == "win32":
            os.startfile(str(path))
        else:
            webbrowser.open(Path(path).as_uri())
    except Exception:
        webbrowser.open(Path(path).as_uri())
    print(f"→ נפתח בדפדפן. לא נפתח? פתחו ידנית: {path}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--open", default="studio", choices=["studio", "site", "none"])
    a = ap.parse_args()
    run = Path(a.run).expanduser()
    if not (run / "course.json").exists():
        fail(f"אין {run / 'course.json'}")
    course = json.loads((run / "course.json").read_text(encoding="utf-8"))
    extract = json.loads((run / "extract.json").read_text(encoding="utf-8"))
    check(course, extract)

    slim = [{k: s[k] for k in ("n", "file", "page", "deck", "label", "w", "h")} for s in extract["slides"]]
    pages = [{k: p[k] for k in ("n", "file", "page", "label")} for p in extract["pages"]]
    data = dict(course, slides=slim, pages=pages)

    site = write_page(run, "site", "site.html", data, extract, False)
    lab = course.get("lab") or {}
    if lab.get("file"):
        src = run / lab["file"]
        if src.exists():
            shutil.copy(src, run / "site" / "lab.html")
        else:
            print(f"! המעבדה {lab['file']} לא נמצאה ב-RUN, האתר ייבנה בלעדיה")
            data["lab"] = None
            (run / "site" / "data.js").write_text("window.COURSE = " + json.dumps(data, ensure_ascii=False) + ";\n",
                                                  encoding="utf-8")
    studio = write_page(run, "studio", "studio.html", data, extract, True)

    n_hints = sum(len(e.get("hints", [])) for e in course["exercises"])
    print(f"✓ אתר התרגול: {site}")
    print(f"✓ הממשק המונפש: {studio}")
    print(f"  {len(slim)} שקפים · {len(course['topics'])} נושאים · {len(course['exercises'])} תרגילים · {n_hints} רמזים")
    if a.open != "none":
        open_page(studio if a.open == "studio" else site)


if __name__ == "__main__":
    main()
