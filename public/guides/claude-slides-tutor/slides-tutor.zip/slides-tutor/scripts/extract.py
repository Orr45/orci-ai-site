"""שלב 1: הופך את המצגות ואת דפי התרגיל לתמונות + טקסט, כדי שקלוד יוכל לקרוא אותם והממשק יוכל להציג אותם.

  python scripts/extract.py --slides "הרצאה 1.pdf" "הרצאה 2.pdf" --homework "תרגיל 2.pdf" --out RUN

כותב:
  RUN/slides/s001.jpg ...   כל שקף מכל המצגות, ממוספר ברצף
  RUN/pages/h001.jpg ...    כל עמוד מדפי התרגיל / החוברת
  RUN/extract.json          לכל שקף ועמוד: מספר, קובץ מקור, עמוד, תווית ("הרצאה 2 · שקף 9") וטקסט גולמי

הערה: בקובצי PDF רבים בעברית הטקסט יוצא הפוך (סדר ויזואלי). זה בסדר: קלוד קורא את התמונות כשהטקסט לא ברור.
קובץ PPTX: אם מותקן LibreOffice הוא יומר לבד ל-PDF. אחרת מבקשים לשמור אותו כ-PDF (PowerPoint: קובץ ← שמירה בשם ← PDF).
"""
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):  # Windows consoles default to cp1252/cp1255 and crash on Hebrew / ✓
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

try:
    import pymupdf as fitz  # PyMuPDF (the old name "fitz" prints a FutureWarning)
except ImportError:
    try:
        import fitz
    except ImportError:
        sys.exit("חסרה הספרייה PyMuPDF. התקנה: pip install -r requirements.txt")

SLIDE_W = 1280
PAGE_W = 1100


def _run(cmd, timeout=300):
    try:
        subprocess.run(cmd, check=True, capture_output=True, timeout=timeout)
    except Exception:
        pass


def _soffice():
    for c in (shutil.which("soffice"), shutil.which("libreoffice"),
              "/Applications/LibreOffice.app/Contents/MacOS/soffice",
              r"C:\Program Files\LibreOffice\program\soffice.exe",
              r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"):
        if c and Path(c).exists():
            return c
    return None


def converters():
    """Which tools on this computer can turn a PowerPoint into a PDF (best first)."""
    found = []
    if sys.platform == "darwin" and Path("/Applications/Microsoft PowerPoint.app").exists():
        found.append("PowerPoint")
    if sys.platform == "win32" and shutil.which("powershell"):
        found.append("PowerPoint")  # only works if Office is installed; tried and skipped otherwise
    if _soffice():
        found.append("LibreOffice")
    if sys.platform == "darwin" and Path("/Applications/Keynote.app").exists():
        found.append("Keynote")
    return found


def to_pdf(path: Path, tmp: Path) -> Path:
    suf = path.suffix.lower()
    if suf == ".pdf":
        return path
    if suf not in (".pptx", ".ppt", ".key", ".docx", ".doc"):
        sys.exit(f"סוג קובץ לא נתמך: {path.name}. צריך PDF או PowerPoint.")
    out = tmp / (path.stem + ".pdf")
    src, dst = str(path.resolve()), str(out.resolve())
    q = lambda x: x.replace("\\", "\\\\").replace('"', '\\"')
    for tool in converters() * 2:  # the second round retries: a cold Keynote/PowerPoint often fails the first call
        if out.exists():
            break
        if tool == "PowerPoint" and suf in (".pptx", ".ppt") and sys.platform == "darwin":
            _run(["osascript", "-e", f'''tell application "Microsoft PowerPoint"
  launch
  delay 2
  open POSIX file "{q(src)}"
  set p to active presentation
  save p in POSIX file "{q(dst)}" as save as PDF
  close p saving no
end tell'''])
        elif tool == "PowerPoint" and suf in (".pptx", ".ppt") and sys.platform == "win32":
            _run(["powershell", "-NoProfile", "-Command",
                  f"$a=New-Object -ComObject PowerPoint.Application; $d=$a.Presentations.Open('{src.replace(chr(39), chr(39) * 2)}',-1,0,0); "
                  f"$d.SaveAs('{dst.replace(chr(39), chr(39) * 2)}',32); $d.Close(); $a.Quit()"])
        elif tool == "LibreOffice":
            _run([_soffice(), "--headless", "--convert-to", "pdf", "--outdir", str(tmp), src])
        elif tool == "Keynote" and suf in (".pptx", ".ppt", ".key"):
            _run(["osascript", "-e", f'''tell application "Keynote"
  launch
  delay 2
  set d to open POSIX file "{q(src)}"
  export d to POSIX file "{q(dst)}" as PDF
  close d saving no
end tell'''])
        if out.exists():
            print(f"  {path.name} → PDF ({tool})")
            if tool == "Keynote":
                print("  ! Keynote לפעמים חותך טבלאות רחבות. בדקו את השקפים עם טבלה, ואם משהו חסר, בקשו PDF מהמרצה או מ-PowerPoint.")
    if not out.exists():
        sys.exit(f"לא הצלחתי להמיר את {path.name} ל-PDF במחשב הזה. בקשו מהמשתמש לשמור אותה כ-PDF "
                 "(PowerPoint: קובץ ← שמירה בשם ← PDF. Google Slides: קובץ ← הורדה ← PDF. "
                 "או להוריד את ה-PDF מאתר הקורס) ולהריץ שוב.")
    return out


def deck_label(path: Path, idx: int) -> str:
    stem = path.stem.lower()
    m = re.search(r"(\d+)", stem)
    if not m:
        return f"מצגת {idx}"
    kind = "שבוע" if re.search(r"week|שבוע", stem) else "שיעור" if re.search(r"class|שיעור", stem) else \
        "פרק" if re.search(r"chapter|פרק", stem) else "מצגת" if "מצגת" in stem else "הרצאה"
    return f"{kind} {m.group(1)}"


def contact_sheets(run: Path, folder: str, items, per=4):
    """גיליונות 2×2 לקריאה מהירה: 4 שקפים בתמונה אחת, עם המספר n על כל אחד."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return 0
    out = run / "sheets"
    out.mkdir(exist_ok=True)
    count = 0
    for k in range(0, len(items), per):
        group = items[k:k + per]
        ims = [Image.open(run / folder / it["file"]).convert("RGB") for it in group]
        w = max(i.width for i in ims) // 2
        cells = [i.resize((w, int(i.height * w / i.width))) for i in ims]
        h = max(c.height for c in cells)
        sheet = Image.new("RGB", (w * 2 + 12, h * 2 + 12), "white")
        d = ImageDraw.Draw(sheet)
        for j, c in enumerate(cells):
            x, y = (j % 2) * (w + 12), (j // 2) * (h + 12)
            sheet.paste(c, (x, y))
            d.rectangle([x, y, x + 70, y + 34], fill="black")
            d.text((x + 8, y + 8), f"n={group[j]['n']}", fill="yellow")
        count += 1
        sheet.save(out / f"{folder}-{count:02d}.jpg", quality=80)
    return count


def render(pdf: Path, out_dir: Path, prefix: str, start: int, width: int):
    doc = fitz.open(pdf)
    items = []
    for i, page in enumerate(doc):
        n = start + i
        zoom = width / page.rect.width
        pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
        name = f"{prefix}{n:03d}.jpg"
        pix.save(out_dir / name, jpg_quality=82)
        text = " ".join(page.get_text().split())
        items.append({"n": n, "file": name, "page": i + 1, "w": pix.width, "h": pix.height, "text": text[:1500]})
    return items


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slides", nargs="+", required=True, help="קובצי המצגות (PDF / PPTX)")
    ap.add_argument("--homework", nargs="*", default=[], help="דפי תרגיל / חוברת / מבחן (PDF)")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    run = Path(a.out).expanduser()
    for sub in ("slides", "pages", "sheets"):
        if (run / sub).exists():
            shutil.rmtree(run / sub)
    (run / "slides").mkdir(parents=True, exist_ok=True)
    (run / "pages").mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp())

    slides, pages = [], []
    for idx, f in enumerate(a.slides, 1):
        src = Path(f).expanduser()
        pdf = to_pdf(src, tmp)
        label = deck_label(src, idx)
        for it in render(pdf, run / "slides", "s", len(slides) + 1, SLIDE_W):
            it.update(source=src.name, deck=label, label=f"{label} · שקף {it['page']}")
            slides.append(it)
    for f in a.homework:
        src = Path(f).expanduser()
        pdf = to_pdf(src, tmp)
        for it in render(pdf, run / "pages", "h", len(pages) + 1, PAGE_W):
            it.update(source=src.name, label=f"{src.stem} · עמוד {it['page']}")
            pages.append(it)

    (run / "extract.json").write_text(json.dumps({"slides": slides, "pages": pages}, ensure_ascii=False, indent=1),
                                      encoding="utf-8")
    sheets = contact_sheets(run, "slides", slides) + contact_sheets(run, "pages", pages)
    decks = sorted({s["deck"] for s in slides})
    print(f"✓ {len(slides)} שקפים מ-{len(decks)} מצגות, {len(pages)} עמודי תרגיל → {run}")
    if sheets:
        print(f"  {sheets} גיליונות לקריאה מהירה ב-sheets/ (4 שקפים בתמונה, עם המספר n)")
    print("עכשיו: לקרוא את sheets/ (או slides/ ו-pages/) ולכתוב את RUN/course.json (ראו reference/course-format.md)")


if __name__ == "__main__":
    main()
