// brands/<slug>/brand.js — copy this file and fill ONLY the block of the style you chose.
window.BRAND = {
  name: "שם העסק",
  handle: "business.handle",             // shown on the opening profile card
  bio: "שורה אחת: מה העסק עושה · עיר",
  style: "cinematic",                    // "cinematic" | "broadcast" | "editorial"
  duration: 8.0,                         // seconds
  musicStart: 0,                         // where the drop is in brands/<slug>/music.mp3 (optional)
  colors: { bg: "#0d0906", accent: "#d8a657", ink: "#f6efe3", sub: "#e8bd74" },
  font: { he: "Frank Ruhl Libre", la: "Cinzel" },
  logo: "assets/logo.png", logoFit: "80%",   // "cover" for a square photo-like logo
  photos: ["assets/p1.jpg", "assets/p2.jpg", "assets/p3.jpg", "assets/p4.jpg", "assets/p5.jpg", "assets/p6.jpg"],

  // a place you visit: venue, hotel, restaurant
  cinematic: {
    hero: "assets/p1.jpg", heroPos: "50% 45%",   // the photo behind the opening doors
    headline: "חתונה בטירה.",                    // 2–3 words
    second: "assets/p2.jpg",                     // the second full-screen photo
    info: ["עובדה 1", "עובדה 2", "עובדה 3"],      // three short true facts
    tagline: "הסלוגן של העסק."
  },

  // a service with a person: barber, trainer, clinic
  broadcast: {
    menu: ["שירות 1", "שירות 2", "שירות 3"],
    price: "₪70",                                // only a real price
    cardPhoto: "assets/p1.jpg", cardName: "FIRST LAST", cardSub: "BRAND · CITY", cardNo: "7",
    cardTitle: "כרטיס שחקן",
    stats: [["שנות ניסיון", "7"], ["שירות", "₪70"], ["משהו מיוחד", "רק אצלנו"]],
    stamp: "משפט סיום קצר."
  },

  // a product, fashion, a shop
  editorial: {
    looks: ["assets/p1.jpg", "assets/p2.jpg"],    // two portrait photos
    label: "PRODUCT NAME",
    options: ["S", "M", "L", "XL"], pick: 2, optionsTitle: "SELECT SIZE",
    sticker: "נוסף לסל",
    tagline: "סלוגן קצר.",
    wordmark: "BRAND"
  }
};
