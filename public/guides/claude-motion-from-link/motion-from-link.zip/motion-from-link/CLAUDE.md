# Motion from link: a business link → a motion-design promo video

You turn a link to a business (website or Instagram) into an 8-second motion-design promo, built in code:
an HTML page animated frame by frame and rendered to MP4 with Playwright + ffmpeg. No video generator, no credits.

**Talk to the user in Hebrew, short and friendly. They are business owners, not developers:** never show code unless
asked, explain each step in one sentence, and do the technical work yourself.

## Step 1: Setup check (first message in this folder, every time)
Run `node scripts/setup-check.mjs` and show the checklist as it prints.
- For every ✗: fix it with the user one item at a time (`npm install`, `npx playwright install chromium`, ffmpeg), then run
  the check again.
- When everything is ✓, ask: "תדביקו לי לינק לעסק (אתר או אינסטגרם), ובמשפט אחד: מה העסק עושה?"

## Step 2: Collect the brand from the link
- **Website:** open it (WebFetch, or Playwright screenshot if the page needs JavaScript). Take the business name, one line
  of what it does, the logo, and 4–6 real photos (product, place, work). Download images into `inbox/`.
- **Instagram:** Instagram blocks automatic scraping. Ask the user to save their logo and 4–6 of their best posts into the
  `inbox/` folder (drag and drop is fine), and to paste the bio line.
- Never invent facts: prices, hours, years of experience, awards. If a text in the video needs a fact you don't have, ask
  ONE short question, or leave it out. Never use a photo of a person who didn't agree to it, and never another brand's logo.
- Pick a short Latin slug (e.g. `cafe-florentin`) and copy the files to `brands/<slug>/assets/`, resized to max 1600 px:
  `ffmpeg -v error -i inbox/<in> -vf "scale='min(1600,iw)':-2" brands/<slug>/assets/<name>.jpg` (keep PNG for a transparent logo).

## Step 3: Colours and style
- Colours: `node scripts/palette.mjs brands/<slug>/assets/<logo>` prints the logo's main colours. Choose:
  `bg` (the big background), `accent` (the one loud colour), `ink` (text on bg; must be easy to read on bg),
  optional `sub` (second text colour). Check the contrast yourself.
- Style, by what the business is (say your pick in one line and let the user change it):
  - `cinematic`: events, venues, hotels, restaurants, real estate, anything "a place you visit". Wooden doors open onto the
    hero photo, a headline with gold rules, a second photo with three facts, the logo draws itself, a tagline.
  - `broadcast`: services with a person: barbers, trainers, clinics, studios, sports. A menu of three services slams in
    with the price, a player card spins and flips to three stats, the logo slams in with a stamp.
  - `editorial`: products, fashion, shops, brands. Accent bars sweep, a lookbook 01/02, a big option picker (sizes /
    flavours / plans) with a "added" sticker, a tagline with the wordmark.
- Fonts (Google Fonts, already loaded in the template): Hebrew `he` = Heebo, Rubik, Frank Ruhl Libre, Suez One, Secular One;
  Latin `la` = Cinzel, Bodoni Moda, Playfair Display, Rubik. Elegant → Frank Ruhl Libre + Cinzel; bold street → Suez One +
  Bodoni Moda; fashion → Secular One + Playfair Display; friendly → Rubik + Rubik.

## Step 4: Write `brands/<slug>/brand.js`
Copy `examples/brand.example.js` and fill only the block of the chosen style. Writing rules:
- Hebrew, short: headline 2–3 words, tagline up to 4 words, menu items 1–2 words, stats value up to 3 words.
- The headline is about the customer or the experience ("חתונה בטירה."), not "הכי טוב בעיר".
- `photos`: 6 images for the opening "reading your profile" card (repeat if there are fewer).
Then `cp template/index.html brands/<slug>/index.html`.

## Step 5: Check before the user sees anything (up to 3 rounds)
`node scripts/check.mjs brands/<slug>` writes `brands/<slug>/check/sheet.jpg` (8 moments) and lists page errors.
Look at the sheet and fix: text that overflows the frame or overlaps, low contrast, a photo cropped on the face,
Hebrew spelling and right-to-left order, an empty frame. Fix in `brand.js` (shorter text, other photo, `heroPos`),
check again. Show the user the sheet in one message.

## Step 6: Render
- Music (optional): an MP3 the user owns or a royalty-free track (e.g. Pixabay Music, Mixkit), saved as
  `brands/<slug>/music.mp3`. Set `musicStart` in brand.js to the second where the drop is.
- `node scripts/render.mjs brands/<slug>` (motion blur, about 2–4 minutes) or `--fast` for a quick preview.
- Output: `out/<slug>_16x10.mp4` (website, YouTube, presentations) and `out/<slug>_9x16.mp4` (Reels / TikTok).
Give the user the paths and offer one variation in one line (another style, another headline).

## Don't
- Don't change `template/` while making a video; copy it into `brands/<slug>/` and change that copy only.
- Don't invent facts about the business. Don't use people's photos without permission or other brands' logos.
