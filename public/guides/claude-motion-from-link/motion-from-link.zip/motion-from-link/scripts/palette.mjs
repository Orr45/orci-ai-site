// node scripts/palette.mjs <image>  -> the 6 most common colours (ignores near-white / transparent)
import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const file = process.argv[2];
const ext = file.split('.').pop().toLowerCase().replace('jpg', 'jpeg');
const data = `data:image/${ext};base64,${readFileSync(file).toString('base64')}`;
const b = await chromium.launch(); const p = await b.newPage();
const res = await p.evaluate(async (src) => {
  const im = new Image(); im.src = src; await im.decode();
  const c = document.createElement('canvas'); const s = 120 / Math.max(im.width, im.height);
  c.width = Math.round(im.width * s); c.height = Math.round(im.height * s);
  const g = c.getContext('2d'); g.drawImage(im, 0, 0, c.width, c.height);
  const d = g.getImageData(0, 0, c.width, c.height).data, bins = {};
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] < 128) continue;
    const r = d[i] >> 4, gg = d[i + 1] >> 4, bb = d[i + 2] >> 4;
    if (r > 14 && gg > 14 && bb > 14) continue;
    const k = (r << 8) | (gg << 4) | bb; bins[k] = (bins[k] || 0) + 1;
  }
  return Object.entries(bins).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, n]) => {
    k = +k; const h = v => ((v * 16 + 8).toString(16)).padStart(2, '0');
    return { hex: '#' + h(k >> 8) + h((k >> 4) & 15) + h(k & 15), share: n };
  });
}, data);
await b.close();
const tot = res.reduce((a, r) => a + r.share, 0);
res.forEach(r => console.log(r.hex, Math.round(100 * r.share / tot) + '%'));
