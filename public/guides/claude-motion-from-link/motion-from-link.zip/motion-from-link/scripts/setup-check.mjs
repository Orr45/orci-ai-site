// node scripts/setup-check.mjs  -> checklist of what the skill needs
import { execSync } from 'node:child_process';
import { existsSync } from 'node:fs';
const ok = (b, label, fix) => console.log(`${b ? '✓' : '✗'} ${label}${b ? '' : `  →  ${fix}`}`);
const major = +process.versions.node.split('.')[0];
ok(major >= 18, `Node.js ${process.versions.node}`, 'התקינו Node 18 ומעלה מ-nodejs.org');
let ff = false; try { execSync('ffmpeg -version', { stdio: 'ignore' }); ff = true; } catch {}
ok(ff, 'ffmpeg', 'Mac: brew install ffmpeg · Windows: winget install ffmpeg');
const pw = existsSync('node_modules/playwright');
ok(pw, 'Playwright', 'npm install');
let chrome = false;
if (pw) { try { const { chromium } = await import('playwright'); chrome = existsSync(chromium.executablePath()); } catch {} }
ok(chrome, 'Chromium של Playwright', 'npx playwright install chromium');
process.exit(major >= 18 && ff && pw && chrome ? 0 : 1);
