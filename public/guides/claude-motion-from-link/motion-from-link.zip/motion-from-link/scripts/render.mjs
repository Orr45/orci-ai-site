// node scripts/render.mjs brands/<slug> [--fast]
// -> out/<slug>_16x10.mp4 (1920x1246, 30 fps, motion blur) + out/<slug>_9x16.mp4 (1080x1920 for Reels/TikTok)
// music: brands/<slug>/music.mp3 (optional), starting at BRAND.musicStart seconds
import { chromium } from 'playwright';
import { execSync } from 'node:child_process';
import { mkdirSync, rmSync, existsSync, readFileSync } from 'node:fs';
import { resolve, basename } from 'node:path';
const dir = resolve(process.argv[2]); const slug = basename(dir); const fast = process.argv.includes('--fast');
const FPS = 30, SUB = fast ? 1 : 4, SCALE = 1920 / 1512;
const fr = resolve(`out/.frames_${slug}`); rmSync(fr, { recursive: true, force: true }); mkdirSync(fr, { recursive: true }); mkdirSync('out', { recursive: true });
const b = await chromium.launch();
const probe = await b.newPage({ viewport: { width: 1512, height: 982 } });
await probe.goto(`file://${dir}/index.html?render=1`); await probe.waitForFunction('window.READY === true', null, { timeout: 60000 });
const T = await probe.evaluate(() => window.T_END); const brand = await probe.evaluate(() => window.BRAND); await probe.close();
const n = Math.round(T * FPS * SUB), workers = 4;
console.log(`מרנדר ${slug}: ${T}s, ${n} פריימים${fast ? ' (מהיר)' : ' (עם מושן בלר)'}`);
async function work(k) {
  const p = await b.newPage({ viewport: { width: 1512, height: 982 }, deviceScaleFactor: SCALE });
  await p.goto(`file://${dir}/index.html?render=1`); await p.waitForFunction('window.READY === true', null, { timeout: 60000 });
  for (let i = k; i < n; i += workers) { await p.evaluate(x => seek(x), i / (FPS * SUB)); await p.screenshot({ path: `${fr}/f_${String(i).padStart(5, '0')}.jpg`, type: 'jpeg', quality: 92, timeout: 120000 }); }
}
await Promise.all([...Array(workers).keys()].map(work)); await b.close();
const music = existsSync(`${dir}/music.mp3`);
const blurF = SUB > 1 ? `tmix=frames=${SUB},` : '';
const vf = `${blurF}fps=${FPS},crop=trunc(iw/2)*2:trunc(ih/2)*2:0:0`;
const a = music ? `-ss ${brand.musicStart || 0} -t ${T} -i "${dir}/music.mp3" -af "afade=t=out:st=${Math.max(0, T - .6)}:d=.6"` : '';
const wide = `out/${slug}_16x10.mp4`;
execSync(`ffmpeg -v error -y -framerate ${FPS * SUB} -i "${fr}/f_%05d.jpg" ${a} -vf "${vf}" -c:v libx264 -crf 18 -pix_fmt yuv420p ${music ? '-c:a aac -b:a 192k -shortest' : ''} -movflags +faststart "${wide}"`);
const tall = `out/${slug}_9x16.mp4`;
execSync(`ffmpeg -v error -y -i "${wide}" -filter_complex "[0:v]scale=-2:1920,crop=1080:1920,boxblur=30:2,eq=brightness=-0.12[bg];[0:v]scale=1080:-2[fg];[bg][fg]overlay=0:(H-h)/2" -c:v libx264 -crf 18 -pix_fmt yuv420p ${music ? '-c:a copy' : ''} -movflags +faststart "${tall}"`);
rmSync(fr, { recursive: true, force: true });
console.log(`מוכן:\n  ${wide}\n  ${tall}`);
