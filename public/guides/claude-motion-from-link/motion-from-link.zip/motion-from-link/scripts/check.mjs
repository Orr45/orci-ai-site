// node scripts/check.mjs brands/<slug>  -> brands/<slug>/check/sheet.jpg (8 moments) + any page errors
import { chromium } from 'playwright';
import { execSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
const dir = resolve(process.argv[2]); const out = `${dir}/check`; mkdirSync(out, { recursive: true });
const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1512, height: 982 } });
const errs = []; p.on('pageerror', e => errs.push(String(e))); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
await p.goto(`file://${dir}/index.html?render=1`); await p.waitForFunction('window.READY === true', null, { timeout: 60000 });
const times = [0.6, 1.6, 2.6, 3.6, 4.6, 5.6, 6.6, 7.6];
for (const [i, t] of times.entries()) { await p.evaluate(x => seek(x), t); await p.screenshot({ path: `${out}/t${i}.jpg`, type: 'jpeg', quality: 85 }); }
await b.close();
execSync(`ffmpeg -v error -y -i "${out}/t%d.jpg" -vf "scale=504:-1,tile=4x2" -frames:v 1 "${out}/sheet.jpg"`);
console.log(`${out}/sheet.jpg`); if (errs.length) { console.log('שגיאות בעמוד:'); errs.forEach(e => console.log(' -', e)); process.exit(1); }
