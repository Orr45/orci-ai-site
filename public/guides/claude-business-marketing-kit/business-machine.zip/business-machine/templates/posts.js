/* מכונת העסק: מעצב הפוסטים והסטוריז. משותף לערכה ולממשק המונפש.
   BM.post(spec, B, url) מחזיר אלמנט 1080x1350. BM.story(spec, B, url) מחזיר 1080x1920.
   B = brand.json. url(n) = הנתיב לתמונה n. */
(function () {
  const FONTS = ['Rubik', 'Heebo', 'Assistant', 'Secular One', 'Suez One', 'Frank Ruhl Libre', 'Karantina', 'Amatic SC', 'Varela Round', 'Bellefair', 'Noto Serif Hebrew', 'Alef', 'Fredoka', 'Bona Nova SC', 'Playpen Sans Hebrew'];
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  function injectFonts(B) {
    const fam = [...new Set([B.fonts.display, B.fonts.body, 'Rubik'])].filter(f => FONTS.includes(f));
    const href = 'https://fonts.googleapis.com/css2?' + fam.map(f => 'family=' + f.replace(/ /g, '+') + ':wght@400;500;700;800;900').join('&') + '&display=swap';
    if (!document.querySelector(`link[href="${href}"]`)) { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = href; document.head.appendChild(l); }
  }
  function lum(hex) { const n = parseInt(hex.slice(1), 16); const r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255; return (0.299 * r + 0.587 * g + 0.114 * b) / 255; }
  const on = hex => lum(hex) > .6 ? '#141414' : '#ffffff';
  function base(w, h, B) {
    const el = document.createElement('div');
    el.className = 'bm-canvas';
    el.style.cssText = `width:${w}px;height:${h}px;position:relative;overflow:hidden;direction:rtl;font-family:'${B.fonts.body}',Rubik,sans-serif;background:${B.colors.light};color:${B.colors.dark}`;
    return el;
  }
  const D = B => `font-family:'${B.fonts.display}','${B.fonts.body}',sans-serif`;
  function tag(B, dark, bg) {
    const c = dark ? '#fff' : B.colors.dark;
    const m = bg === B.colors.primary ? (bg === B.colors.accent ? (dark ? '#fff' : B.colors.dark) : B.colors.accent) : B.colors.primary;
    return `<div style="position:absolute;top:44px;right:52px;display:flex;align-items:center;gap:16px;z-index:3">
      <div style="width:64px;height:64px;border-radius:50%;background:${m};color:${on(m)};display:grid;place-items:center;${D(B)};font-size:28px;font-weight:800;letter-spacing:1px">${esc(B.monogram)}</div>
      <div style="${D(B)};font-size:32px;font-weight:800;color:${c};letter-spacing:.5px">${esc(B.name)}</div></div>`;
  }
  const img = (u, css = '') => `<img src="${u}" crossorigin="anonymous" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;${css}">`;
  const L = {
    'photo-headline'(s, B, u) {
      return `${img(u(s.photo))}<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.25) 0%,transparent 30%,transparent 45%,${B.colors.dark}ee 82%)"></div>${tag(B, true)}
      <div style="position:absolute;right:60px;left:60px;bottom:80px;color:#fff">
        <div style="${D(B)};font-size:104px;line-height:1;font-weight:800">${esc(s.headline)}</div>
        ${s.sub ? `<div style="margin-top:26px;font-size:40px;line-height:1.3;opacity:.92">${esc(s.sub)}</div>` : ''}
        <div style="margin-top:34px;width:120px;height:10px;border-radius:5px;background:${B.colors.accent}"></div></div>`;
    },
    'split'(s, B, u) {
      return `<div style="position:absolute;top:0;left:0;right:0;height:62%">${img(u(s.photo))}</div>${tag(B, true)}
      <div style="position:absolute;bottom:0;left:0;right:0;height:38%;background:${B.colors.primary};color:${on(B.colors.primary)};padding:60px 64px">
        <div style="${D(B)};font-size:86px;line-height:1.02;font-weight:800">${esc(s.headline)}</div>
        ${s.sub ? `<div style="margin-top:22px;font-size:36px;line-height:1.3;opacity:.9">${esc(s.sub)}</div>` : ''}</div>`;
    },
    'big-number'(s, B, u) {
      return `<div style="position:absolute;inset:0;background:${B.colors.accent}"></div>${tag(B, lum(B.colors.accent) < .6)}
      <div style="position:absolute;top:210px;right:64px;left:64px;color:${on(B.colors.accent)}">
        <div style="${D(B)};font-size:300px;line-height:.9;font-weight:900;letter-spacing:-6px">${esc(s.number || '')}</div>
        <div style="${D(B)};margin-top:30px;font-size:80px;line-height:1.05;font-weight:800">${esc(s.headline)}</div>
        ${s.sub ? `<div style="margin-top:22px;font-size:36px;line-height:1.35;opacity:.9">${esc(s.sub)}</div>` : ''}</div>
      <div style="position:absolute;left:-70px;bottom:-70px;width:520px;height:520px;border-radius:50%;overflow:hidden;border:16px solid ${B.colors.light}">${img(u(s.photo))}</div>`;
    },
    'quote'(s, B, u) {
      return `<div style="position:absolute;inset:0;background:${B.colors.light}"></div>${tag(B, false)}
      <div style="position:absolute;top:150px;right:64px;${D(B)};font-size:340px;line-height:1;color:${B.colors.accent};opacity:.9">”</div>
      <div style="position:absolute;top:420px;right:72px;left:72px;color:${B.colors.dark}">
        <div style="font-size:30px;letter-spacing:6px;color:${B.colors.accent}">★★★★★</div>
        <div style="${D(B)};margin-top:24px;font-size:66px;line-height:1.22;font-weight:700">${esc(s.headline)}</div>
        <div style="margin-top:34px;display:flex;align-items:center;gap:22px">
          <div style="width:110px;height:110px;border-radius:50%;overflow:hidden;position:relative">${img(u(s.photo))}</div>
          <div style="font-size:36px;font-weight:700">${esc(s.sub || '')}</div></div></div>`;
    },
    'offer'(s, B, u) {
      return `<div style="position:absolute;inset:0;background:${B.colors.dark}"></div>${tag(B, true)}
      <div style="position:absolute;top:170px;right:90px;left:90px;height:640px;border-radius:40px;overflow:hidden;transform:rotate(-3deg);box-shadow:0 40px 80px rgba(0,0,0,.45)">${img(u(s.photo))}</div>
      <div style="position:absolute;top:120px;left:70px;width:230px;height:230px;border-radius:50%;background:${B.colors.accent};color:${on(B.colors.accent)};display:grid;place-items:center;text-align:center;${D(B)};font-size:50px;font-weight:900;line-height:1;transform:rotate(12deg);z-index:2;padding:20px">${esc(s.badge || 'מבצע')}</div>
      <div style="position:absolute;right:70px;left:70px;bottom:90px;color:#fff">
        <div style="${D(B)};font-size:88px;line-height:1.02;font-weight:800">${esc(s.headline)}</div>
        ${s.sub ? `<div style="margin-top:24px;display:inline-block;padding:16px 34px;border-radius:99px;background:${B.colors.primary};color:${on(B.colors.primary)};font-size:36px;font-weight:700">${esc(s.sub)}</div>` : ''}</div>`;
    },
    'tips'(s, B, u) {
      const items = (s.items || []).slice(0, 4);
      return `<div style="position:absolute;inset:0;background:${B.colors.light}"></div>
      <div style="position:absolute;top:0;left:0;width:38%;height:100%">${img(u(s.photo))}</div>${tag(B, false)}
      <div style="position:absolute;top:180px;right:60px;width:56%;color:${B.colors.dark}">
        <div style="${D(B)};font-size:78px;line-height:1.02;font-weight:800">${esc(s.headline)}</div>
        ${items.map((t, i) => `<div style="display:flex;gap:22px;align-items:flex-start;margin-top:40px">
          <div style="flex:none;width:76px;height:76px;border-radius:22px;background:${B.colors.accent};color:${on(B.colors.accent)};display:grid;place-items:center;${D(B)};font-size:44px;font-weight:900">${i + 1}</div>
          <div style="font-size:38px;line-height:1.3;padding-top:6px">${esc(t)}</div></div>`).join('')}</div>`;
    },
    'frame'(s, B, u) {
      return `<div style="position:absolute;inset:0;background:${B.colors.primary}"></div>${tag(B, lum(B.colors.primary) < .6, B.colors.primary)}
      <div style="position:absolute;top:150px;right:70px;left:70px;height:860px;background:#fff;padding:22px 22px 0;box-shadow:0 30px 70px rgba(0,0,0,.35);transform:rotate(2deg)">
        <div style="position:relative;width:100%;height:740px;overflow:hidden">${img(u(s.photo))}</div>
        <div style="font-family:'Amatic SC','Karantina',sans-serif;font-size:72px;font-weight:700;text-align:center;color:#222;line-height:1.2">${esc(s.sub || '')}</div></div>
      <div style="position:absolute;right:70px;left:70px;bottom:90px;${D(B)};font-size:78px;line-height:1.05;font-weight:800;color:${on(B.colors.primary)}">${esc(s.headline)}</div>`;
    },
  };
  function post(s, B, u) { const el = base(1080, 1350, B); el.innerHTML = (L[s.layout] || L['photo-headline'])(s, B, u); return el; }
  function story(s, B, u) {
    const el = base(1080, 1920, B);
    el.innerHTML = `${img(u(s.photo))}<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.35),transparent 25%,transparent 55%,rgba(0,0,0,.6))"></div>${tag(B, true)}
      <div style="position:absolute;right:70px;left:70px;top:46%;text-align:center">
        <div style="display:inline-block;background:#fff;color:#111;${D(B)};font-size:74px;font-weight:800;line-height:1.15;padding:26px 40px;border-radius:30px;box-shadow:0 20px 50px rgba(0,0,0,.3)">${esc(s.text)}</div></div>
      ${s.sticker ? `<div style="position:absolute;bottom:230px;left:50%;transform:translateX(-50%) rotate(-3deg);background:${B.colors.accent};color:${on(B.colors.accent)};font-size:50px;font-weight:800;padding:22px 46px;border-radius:24px;white-space:nowrap">${esc(s.sticker)}</div>` : ''}`;
    return el;
  }
  function scaled(el, w) { const W0 = parseInt(el.style.width), H0 = parseInt(el.style.height), k = w / W0;
    const box = document.createElement('div'); box.className = 'bm-box'; box.style.cssText = `width:${w}px;height:${H0 * k}px;position:relative;overflow:hidden`;
    el.style.transform = `scale(${k})`; el.style.transformOrigin = 'top right'; el.style.position = 'absolute'; el.style.top = '0'; el.style.right = '0';
    box.appendChild(el); return box; }
  window.BM = { post, story, scaled, injectFonts, on, lum, esc };
})();
