"""שלב 1: אוסף את התמונות של העסק, מקטין, ושולף מהן את הצבעים. אופציונלי: קורא את הטקסט מהאתר.

  python scripts/gather.py --photos <תיקייה או קבצים...> [--site https://...] --out RUN

כותב:
  RUN/photos/p01.jpg ...   עותקים מוקטנים (עד 1600px). המקור לא זז
  RUN/gather.json          לכל תמונה: קובץ, מידות, 5 הצבעים הבולטים שלה. פלטה כללית. טקסט מהאתר (אם יש)
"""
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):  # Windows consoles default to cp1252/cp1255 and crash on Hebrew / ✓
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse
import colorsys
import html
import json
import re
import sys
import urllib.request
from pathlib import Path

try:
    from PIL import Image, ImageOps
except ImportError:
    sys.exit("חסרה הספרייה Pillow. התקנה: pip install pillow")
try:
    from pillow_heif import register_heif_opener
    register_heif_opener()
except ImportError:
    pass

EXT = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif"}
MAX_PHOTOS = 12


def collect(paths):
    out = []
    for p in paths:
        p = Path(p).expanduser()
        if p.is_dir():
            out += sorted(x for x in p.iterdir() if x.suffix.lower() in EXT)
        elif p.suffix.lower() in EXT:
            out.append(p)
    return out[:MAX_PHOTOS]


def hexc(rgb):
    return "#%02x%02x%02x" % tuple(int(v) for v in rgb)


def _dist(a, b):
    ra, rb = [int(a[i:i + 2], 16) for i in (1, 3, 5)], [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return sum((x - y) ** 2 for x, y in zip(ra, rb)) ** .5


def accents(small):
    """הצבעים החיים בתמונה (פרחים, שלט, מוצר): פיקסלים רוויים, מקובצים לפי גוון, ממוצע של כל קבוצה."""
    bins = {}
    px = list(small.get_flattened_data()) if hasattr(small, "get_flattened_data") else list(small.getdata())
    for r, g, b in px:
        h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        if s > .16 and v > .3:
            k = (int(h * 36) % 36, v > .72)
            t = bins.setdefault(k, [0, 0, 0, 0])
            t[0] += 1; t[1] += r; t[2] += g; t[3] += b
    out = []
    for k, (n, r, g, b) in sorted(bins.items(), key=lambda kv: -kv[1][0]):
        if n / len(px) < .003:
            break
        rgb = (r / n, g / n, b / n)
        h, l, s = colorsys.rgb_to_hls(*(v / 255 for v in rgb))
        sv = colorsys.rgb_to_hsv(*(v / 255 for v in rgb))[1]
        out.append({"hex": hexc(rgb), "share": round(n / len(px), 3), "l": round(l, 2), "s": round(max(s, .3), 2), "_k": sv * (n / len(px)) ** .3})
    out.sort(key=lambda c: -c.pop("_k"))
    return out[:6]


def colors(img, k=16):
    """5 צבעים לכל תמונה: 2 הדומיננטיים + 3 החיים ביותר (פרחים, שלט, מוצר), שונים זה מזה."""
    small = img.convert("RGB").resize((160, 160))
    q = small.quantize(colors=k, method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette()[: k * 3]
    res = []
    for cnt, idx in sorted(q.getcolors(), reverse=True):
        rgb = pal[idx * 3: idx * 3 + 3]
        h, l, s = colorsys.rgb_to_hls(*(v / 255 for v in rgb))
        res.append({"hex": hexc(rgb), "share": round(cnt / (160 * 160), 3), "l": round(l, 2), "s": round(s, 2)})
    picks = res[:2]
    vivid = accents(small) + sorted([c for c in res[2:] if .22 <= c["l"] <= .88 and c["share"] >= .004], key=lambda c: -(c["s"] * 2 + c["share"]))
    for c in vivid:
        if all(_dist(c["hex"], p["hex"]) > 55 for p in picks):
            picks.append(c)
        if len(picks) == 5:
            break
    for c in res:
        if len(picks) == 5:
            break
        if c not in picks:
            picks.append(c)
    return picks


def palette(all_colors):
    """6 צבעים: כהה, בהיר, ועד ארבעה צבעים חיים ושונים זה מזה."""
    pool = sorted(all_colors, key=lambda c: -c["share"])
    dark = min(pool, key=lambda c: c["l"])["hex"]
    light = max(pool, key=lambda c: c["l"])["hex"]
    vivid = sorted(pool, key=lambda c: -(c["s"] * 2 * (1 - abs(c["l"] - .55)) + c["share"] * .5))
    picks = [dark, light]
    for c in vivid:
        if all(_dist(c["hex"], p) > 60 for p in picks):
            picks.append(c["hex"])
        if len(picks) == 6:
            break
    return picks


def read_site(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 business-machine"})
        raw = urllib.request.urlopen(req, timeout=15).read().decode("utf-8", "ignore")
    except Exception as e:
        return {"url": url, "error": str(e)}
    title = re.search(r"<title[^>]*>(.*?)</title>", raw, re.S | re.I)
    desc = re.search(r'<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']', raw, re.I)
    body = re.sub(r"<(script|style|noscript)[^>]*>.*?</\1>", " ", raw, flags=re.S | re.I)
    text = html.unescape(re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", body))).strip()
    return {"url": url, "title": html.unescape(title.group(1).strip()) if title else "",
            "description": html.unescape(desc.group(1)) if desc else "", "text": text[:6000]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--photos", nargs="+", required=True)
    ap.add_argument("--site", default="")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    run = Path(a.out).expanduser()
    (run / "photos").mkdir(parents=True, exist_ok=True)
    files = collect(a.photos)
    if not files:
        sys.exit("לא נמצאו תמונות (jpg / png / webp / heic).")
    photos, allc = [], []
    for i, f in enumerate(files, 1):
        img = ImageOps.exif_transpose(Image.open(f)).convert("RGB")
        img.thumbnail((1600, 1600))
        name = f"p{i:02d}.jpg"
        img.save(run / "photos" / name, quality=86)
        cs = colors(img)
        allc += cs
        photos.append({"n": i, "file": name, "source": f.name, "w": img.width, "h": img.height,
                       "orientation": "portrait" if img.height > img.width * 1.1 else "landscape" if img.width > img.height * 1.1 else "square",
                       "colors": [c["hex"] for c in cs[:5]]})
    data = {"photos": photos, "palette": palette(allc), "site": read_site(a.site) if a.site else None}
    (run / "gather.json").write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"✓ {len(photos)} תמונות → {run / 'photos'}")
    print(f"  פלטה: {' '.join(data['palette'])}")
    if a.site:
        print("  אתר: " + ("נקרא" if data["site"] and not data["site"].get("error") else f"לא נקרא ({data['site'].get('error')})"))
    print("עכשיו: להסתכל על התמונות ולכתוב את RUN/brand.json (ראו reference/brand-format.md)")


if __name__ == "__main__":
    main()
