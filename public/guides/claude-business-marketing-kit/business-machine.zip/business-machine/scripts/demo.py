"""הדוגמה: בונה את כל השיווק של "בוטניקה", סטודיו פרחים לדוגמה (העסק והתמונות נוצרו ב-AI), ופותח את הממשק המונפש.

  python scripts/demo.py [--out runs/demo]
"""
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):  # Windows consoles default to cp1252/cp1255 and crash on Hebrew / ✓
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent

ap = argparse.ArgumentParser()
ap.add_argument("--out", default=str(HERE / "runs/demo"))
ap.add_argument("--open", default="studio", choices=["studio", "kit", "none"])
a = ap.parse_args()
run = Path(a.out).expanduser()
demo = HERE / "demo"
subprocess.run([sys.executable, str(HERE / "scripts/gather.py"), "--photos", str(demo / "photos"), "--out", str(run)], check=True)
shutil.copy(demo / "brand.json", run / "brand.json")
subprocess.run([sys.executable, str(HERE / "scripts/build.py"), "--run", str(run), "--open", a.open], check=True)
