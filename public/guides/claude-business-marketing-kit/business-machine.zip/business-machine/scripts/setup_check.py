"""python3 scripts/setup_check.py  →  רשימת בדיקה של מה שהמכונה צריכה. (בווינדוס: py scripts/setup_check.py)"""
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):  # Windows consoles default to cp1252/cp1255 and crash on Hebrew / ✓
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
VENV_PY = HERE / ".venv" / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
NEEDED = [("PIL", "Pillow (תמונות)"), ("pillow_heif", "pillow-heif (תמונות HEIC מאייפון)")]


def ok(good, label, fix=""):
    print(f"{'✓' if good else '✗'} {label}" + ("" if good else f"  →  {fix}"))
    return good


def main():
    py = sys.version_info >= (3, 9)
    all_ok = ok(py, f"Python {sys.version.split()[0]}", "צריך 3.9 ומעלה: python.org/downloads")
    venv = VENV_PY.exists()
    all_ok &= ok(venv, "סביבה (.venv)", f"{'py' if sys.platform == 'win32' else 'python3'} -m venv .venv")
    for mod, label in NEEDED:
        good = venv and subprocess.run([str(VENV_PY), "-c", f"import {mod}"], capture_output=True).returncode == 0
        all_ok &= ok(good, label, f"{VENV_PY.relative_to(HERE)} -m pip install -r requirements.txt")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
