"""שלב 3: בונה את הערכה ואת הממשק המונפש מתוך RUN/brand.json + RUN/gather.json.

  python scripts/build.py --run RUN [--open studio|kit|none]

כותב:
  RUN/kit/index.html      הערכה: מותג, 9 פוסטים (הורדה כ-PNG), סטוריז, מודעות, לוח תוכן, פרומפטים לתמונות
  RUN/kit/landing.html    דף נחיתה
  RUN/kit/promo.html      פרומו מונפש של 10 שניות (9:16) להקלטת מסך
  RUN/studio/index.html   הממשק המונפש לצילום. F = מסך מלא, R = מההתחלה
התמונות נכנסות ל-data.js (מוקטנות), כך שהכול עובד מקובץ, בלי שרת ובלי אינטרנט (חוץ מהפונטים).
"""
import argparse
import base64
import io
import json
import shutil
import sys
import webbrowser
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent.parent
TPL = HERE / "templates"
LAYOUTS = {"photo-headline", "split", "big-number", "quote", "offer", "tips", "frame"}


def fail(m):
    sys.exit("✗ " + m)


def check(b, n_photos):
    errs = []
    for k in ("name", "field", "monogram", "tagline", "colors", "fonts", "posts"):
        if not b.get(k):
            errs.append(f"חסר השדה {k}")
    for k in ("primary", "accent", "dark", "light"):
        v = (b.get("colors") or {}).get(k, "")
        if not (isinstance(v, str) and v.startswith("#") and len(v) == 7):
            errs.append(f"colors.{k} צריך להיות hex כמו #c68159")
    ok = lambda n: isinstance(n, int) and 1 <= n <= n_photos
    for i, p in enumerate(b.get("posts", []), 1):
        if p.get("layout") not in LAYOUTS:
            errs.append(f"פוסט {i}: layout '{p.get('layout')}' לא קיים ({', '.join(sorted(LAYOUTS))})")
        if not ok(p.get("photo")):
            errs.append(f"פוסט {i}: photo צריך להיות מספר תמונה 1-{n_photos}")
    for i, s in enumerate(b.get("stories", []), 1):
        if not ok(s.get("photo")):
            errs.append(f"סטורי {i}: photo מחוץ לטווח")
    if len(b.get("posts", [])) != 9:
        errs.append(f"צריך בדיוק 9 פוסטים (יש {len(b.get('posts', []))})")
    lnd = b.get("landing") or {}
    if not ok(lnd.get("photo")):
        errs.append("landing.photo צריך להיות מספר תמונה")
    for n in lnd.get("gallery", []):
        if not ok(n):
            errs.append(f"landing.gallery: {n} מחוץ לטווח")
    for n in (b.get("promo") or {}).get("photos", []):
        if not ok(n):
            errs.append(f"promo.photos: {n} מחוץ לטווח")
    for i, p in enumerate(b.get("image_prompts", []), 1):
        if not ok(p.get("photo")):
            errs.append(f"image_prompts {i}: photo מחוץ לטווח")
    if errs:
        fail("בעיות ב-brand.json:\n  " + "\n  ".join(errs))


def data_uri(path, max_side=1080):
    img = Image.open(path).convert("RGB")
    img.thumbnail((max_side, max_side))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=82)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--open", default="studio", choices=["studio", "kit", "none"])
    a = ap.parse_args()
    run = Path(a.run).expanduser()
    for f in ("brand.json", "gather.json"):
        if not (run / f).exists():
            fail(f"אין {run / f}")
    brand = json.loads((run / "brand.json").read_text(encoding="utf-8"))
    gather = json.loads((run / "gather.json").read_text(encoding="utf-8"))
    check(brand, len(gather["photos"]))
    if not brand.get("whatsapp") and not brand.get("instagram"):
        print("! אין whatsapp ואין instagram: כפתורי ההזמנה בדף הנחיתה לא יקשרו לשום מקום. כדאי לבקש מספר וואטסאפ או שם משתמש באינסטגרם.")
    photos = {p["n"]: data_uri(run / "photos" / p["file"]) for p in gather["photos"]}
    g_slim = {"photos": [{k: p[k] for k in ("n", "file", "colors", "orientation")} for p in gather["photos"]],
              "palette": gather["palette"], "site": {"url": gather["site"]["url"]} if gather.get("site") else None}
    js = ("window.BRAND = " + json.dumps(brand, ensure_ascii=False) + ";\n"
          "window.GATHER = " + json.dumps(g_slim, ensure_ascii=False) + ";\n"
          "window.PHOTOS = " + json.dumps(photos) + ";\n")
    for folder, pages in (("kit", {"kit.html": "index.html", "landing.html": "landing.html", "promo.html": "promo.html"}),
                          ("studio", {"studio.html": "index.html"})):
        out = run / folder
        out.mkdir(parents=True, exist_ok=True)
        for src, dst in pages.items():
            shutil.copy(TPL / src, out / dst)
        shutil.copy(TPL / "posts.js", out / "posts.js")
        (out / "data.js").write_text(js, encoding="utf-8")
    assets = len(brand.get("posts", [])) + len(brand.get("stories", [])) + 2 + len(brand.get("ads", [])) + \
        len(brand.get("calendar", [])) + len(brand.get("image_prompts", []))
    print(f"✓ הערכה: {run / 'kit/index.html'}")
    print(f"✓ דף נחיתה: {run / 'kit/landing.html'} · פרומו: {run / 'kit/promo.html'}")
    print(f"✓ הממשק המונפש: {run / 'studio/index.html'}")
    print(f"  {len(photos)} תמונות → {len(brand['posts'])} פוסטים · {len(brand.get('stories', []))} סטוריז · {assets} נכסים")
    if a.open != "none":
        webbrowser.open((run / ("studio/index.html" if a.open == "studio" else "kit/index.html")).as_uri())


if __name__ == "__main__":
    main()
